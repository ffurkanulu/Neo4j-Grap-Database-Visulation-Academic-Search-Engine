const express=require('express')
var bodyParser=require("body-parser");
var encoder= bodyParser.urlencoded();

const neo4j = require('neo4j-driver');
const driver = neo4j.driver("neo4j+s://32d7bb9f.databases.neo4j.io", neo4j.auth.basic("neo4j", "9CYhzGym8gxGFXittrsI0bDFpMR9ivhh0h4FMxwdAyg"));
const session = driver.session();
const session2 = driver.session();




const app =express()

var girsinMi=false;

app.use(express.static('public'))

app.get("/",function(req,res){
    res.sendFile(__dirname +"/public/login.html");
    })

    app.post("/",encoder,function(req,res){
        var email=req.body.username;
        var password=req.body.password;
      //  console.log(email);
      //  console.log(password);
       FindAdmin(email,password,res)
       
     
     
    })

    app.post("/registerDB",encoder,function(req,res){
        var YazarAdi=req.body.YazarAdi;
        var YazarSoyAdi=req.body.YazarSoyAdi;
        var YayinAdi=req.body.YayinAdi;
        var YayinYili=req.body.YayinYili;
        var YayinTürü=req.body.YayinTürü;
        var YayinYeri=req.body.YayinYeri;
        console.log(YazarAdi);
       console.log(YazarSoyAdi);
        console.log(YayinAdi);
        console.log(YayinYili);
        console.log(YayinTürü);
        console.log(YayinYeri);
        VeriTabaniKaydet(YazarAdi,YazarSoyAdi,YayinAdi,YayinYili,YayinTürü,YayinYeri,res);
    })

    app.post("/searchName",encoder,function(req,res){
        
        var name=req.body.name;
        var surname=req.body.surname;
        SearchName(name,surname,res);  
    })
    app.post("/dataGetir",encoder,function(req,res){
        var name=req.body.name;
        var surname=req.body.surname;
        DataGetir(name,surname,res);  
    })
    
    app.post("/searchYayinName",encoder,function(req,res){
        var YayinName=req.body.YayinName;   
        console.log(YayinName);
        SearchYayinName(YayinName,res)
    })
    app.post("/searchYayinYear",encoder,function(req,res){
       
        var YayinYili=req.body.YayinYili;   
        console.log(YayinYili)
        SearchYayinYear(YayinYili,res)
     
    })
   





    app.post("/register",encoder,function(req,res){
        var email=req.body.username;
        var password=req.body.password;
    //    console.log(email);
      //  console.log(password);
        RegisterAdmin(email,password,res)
    })
    async function RegisterAdmin(email,password,res){
        const writeQuery = `MERGE (p1:Admin { email: $email ,password: $password})
       
        RETURN  p1`

// Write transactions allow the driver to handle retries and transient errors
const writeResult = await session.writeTransaction(tx =>
tx.run(writeQuery, { email, password })
)
res.redirect("/");
    }




    async function VeriTabaniKaydet(YazarAdi,YazarSoyAdi,YayinAdi,YayinYili,YayinTürü,YayinYeri,res){
        const writeQuery = `
        MERGE (p1:Person { name: $YazarAdi ,surname: $YazarSoyAdi})
          MERGE(y1:Yayin { name: $YayinAdi ,year: $YayinYili})
          MERGE( t1:Tur { name: $YayinTürü })
          MERGE( y12:YayinYeri { name: $YayinYeri })                
        RETURN  p1,y1,t1,y12`


const writeResult = await session.writeTransaction(tx =>
tx.run(writeQuery, { YazarAdi, YazarSoyAdi,YayinAdi,YayinYili,YayinTürü,YayinYeri })
)


   CreateYazaridirRelationShip(YazarAdi,YazarSoyAdi,YayinAdi,YayinYili,YayinYeri,YayinTürü,res)
  
    }
    


    async function CreateYazaridirRelationShip( YazarAdi, YazarSoyAdi, YayinAdi, YayinYili,YayinYeri,YayinTuru,res){
        const writeQuery = `
        MATCH(p1: Person),(y1: Yayin) WHERE p1.name = $YazarAdi AND p1.surname=$YazarSoyAdi AND y1.name = $YayinAdi AND y1.year = $YayinYili
        Merge (p1) -[stu: Yazaridir]->(y1)       
        `
const writeResult = await session.writeTransaction(tx =>
tx.run(writeQuery, { YazarAdi, YazarSoyAdi,YayinAdi,YayinYili })
)
CreateYeridirRelationShip(YayinAdi,YayinYili,YayinYeri,YayinTuru,res)
    }

    async function CreateYeridirRelationShip( YayinAdi, YayinYili, YayinYeri,YayinTuru,res){
        const writeQuery = `
        MATCH(p1: YayinYeri),(y1: Yayin) WHERE y1.name = $YayinAdi AND y1.year = $YayinYili AND p1.name = $YayinYeri
        Merge (y1) -[stu: Yeridir]->(p1)
        `
const writeResult = await session.writeTransaction(tx =>
tx.run(writeQuery, {YayinAdi,YayinYili,YayinYeri })
)
  CreateTurudurRelationShip(YayinAdi,YayinYili,YayinTuru,res)
    }




    async function CreateTurudurRelationShip( YayinAdi, YayinYili, YayinTuru,res){
        const writeQuery = `
        MATCH (p1:Tur),(y1:Yayin) WHERE y1.name=$YayinAdi AND y1.year=$YayinYili AND p1.name=$YayinTuru
        Merge (y1)-[stu:Turudur]->(p1)
        `
const writeResult = await session.writeTransaction(tx =>
tx.run(writeQuery, {YayinAdi,YayinYili,YayinTuru })
)
   res.redirect("/admin");
    }


    

    function veri(name, surname, yer,yil,tur,isimler,yayinismi){
        this.name = name;
        this.surname = surname;
        this.yer = yer;
        this.yil= yil;
        this.tur = tur;
        this.yayinismi = yayinismi;
        this.isimler =  [];
    }



    
    function friends(name, surname){
        this.name = name;
        this.surname = surname;
    }

    async function SearchName(name,surname,res){
        var liste =[]     
        const readQuery = ` Match(p1:Person)-[:Yazaridir]->(y1:Yayin)
        MATCH (y:Yayin)-[:Turudur]->(a1:Tur)
         MATCH (y:Yayin)-[:Yeridir]->(b1:YayinYeri)      
          WHERE p1.name = $name AND p1.surname = $surname AND y.name=y1.name AND y.year=y1.year 
          RETURN a1.name,b1.name,y1.name,y1.year
           
        `
   const readResult = await session.readTransaction(tx =>
   tx.run(readQuery, { name: name,surname:surname })
)
readResult.records.forEach(record => {   
    var veriNew= new veri(name,surname,record.get("b1.name"),record.get("y1.year"),record.get("a1.name"),"arkadaslar",record.get("y1.name"))   
    liste.push(veriNew)
})
listeFriendEkle(liste,res)

    }
    //AYNI FONKSIYONDAN 2 TANE VAR CINKU SESSİON SIKINTI CIKARIYOR
    async function DataGetir(name,surname,res){
        var liste =[]     
        const readQuery = ` Match(p1:Person)-[:Yazaridir]->(y1:Yayin)
        MATCH (y:Yayin)-[:Turudur]->(a1:Tur)
         MATCH (y:Yayin)-[:Yeridir]->(b1:YayinYeri)      
          WHERE p1.name = $name AND p1.surname = $surname AND y.name=y1.name AND y.year=y1.year 
          RETURN a1.name,b1.name,y1.name,y1.year
           
        `
   const readResult = await session2.readTransaction(tx =>
   tx.run(readQuery, { name: name,surname:surname })
)
readResult.records.forEach(record => {   
    var veriNew= new veri(name,surname,record.get("b1.name"),record.get("y1.year"),record.get("a1.name"),"arkadaslar",record.get("y1.name"))   
    liste.push(veriNew)
})
listeFriendEkle(liste,res)

    }
   


    async function SearchYayinYear(year,res){
        var liste =[]     
        const readQuery = ` MATCH (y1:Yayin) 
        MATCH (y:Yayin)-[:Turudur]->(a1:Tur)       
         MATCH (y:Yayin)-[:Yeridir]->(b1:YayinYeri)   
         MATCH (p2:Person)-[:Yazaridir]->(y:Yayin)   
          WHERE  y1.year=$year AND y.name=y1.name AND y.year=y1.year 
          RETURN a1.name,b1.name,y1.name,y1.year,p2.name,p2.surname
           
        `
   const readResult = await session.readTransaction(tx =>
   tx.run(readQuery, { year:year })
)
readResult.records.forEach(record => {   
    var veriNew= new veri(record.get("p2.name"),record.get("p2.surname"),record.get("b1.name"),record.get("y1.year"),record.get("a1.name"),"arkadaslar",record.get("y1.name"))  
  //  console.log(veriNew) 
    liste.push(veriNew)
})
listeFriendEkle(liste,res)

    }
    async function SearchYayinName(name,res){
        var liste =[]     
        const readQuery = ` MATCH (y1:Yayin) 
        MATCH (y:Yayin)-[:Turudur]->(a1:Tur)       
         MATCH (y:Yayin)-[:Yeridir]->(b1:YayinYeri)   
         MATCH (p2:Person)-[:Yazaridir]->(y:Yayin)   
          WHERE  y1.name=$name AND y.name=y1.name AND y.year=y1.year 
          RETURN a1.name,b1.name,y1.name,y1.year,p2.name,p2.surname
           
        `
   const readResult = await session.readTransaction(tx =>
   tx.run(readQuery, { name:name })
)
readResult.records.forEach(record => {   
    var veriNew= new veri(record.get("p2.name"),record.get("p2.surname"),record.get("b1.name"),record.get("y1.year"),record.get("a1.name"),"arkadaslar",record.get("y1.name"))  
  //  console.log(veriNew) 
    liste.push(veriNew)
})
listeFriendEkle(liste,res)

    }








    async function listeFriendEkle(liste,res){
        
        for(let i = 0; i < liste.length; i++){
            
        var yName=liste[i].yayinismi
        var yYear=liste[i].yil
        console.log(yName)
        console.log(yYear)
        const readQuery = ` MATCH (p:Person)-[:Yazaridir]->(y1:Yayin)
      
        WHERE y1.name = $yName AND y1.year = $yYear
        RETURN p.name,p.surname 
           
        `
   const readResult = await session.readTransaction(tx =>
   tx.run(readQuery, { yName:  yName,yYear: yYear })
)
readResult.records.forEach(record => {   
    var friends2= new friends(record.get("p.name"),record.get("p.surname"))
   liste[i].isimler.push(friends2)
})
        }
       console.log(liste);
       
    
    res.send(liste);
  

    }


   









         


   async function FindAdmin(email,password,res){     
        const readQuery = `MATCH (p:Admin)
        WHERE p.email = $email AND p.password = $password
        RETURN p.email`
   const readResult = await session.readTransaction(tx =>
   tx.run(readQuery, { email: email,password:password })
)
readResult.records.forEach(record => {
    if (record != null)
    {
        res.redirect("/admin");
    }
    else
    {
        girsinMi = false;
    }
})
    }

            app.get("/admin",function(req,res){

                res.sendFile(__dirname +"/public/admin.html");
                
                
                })
                app.get("/SearchEngine",function(req,res){
                   
                    res.sendFile(__dirname +"/public/SearchEngine.html");
                    
                    
                    })
                    app.get("/SearchTable",function(req,res){

                        res.sendFile(__dirname +"/public/SearchTable.html");
                        
                        
                        })
                        
                           
                
            

                        app.post('/index',encoder, function(req, res) {   
                            var isim=req.body.isim; 
                            console.log("calıstıııııııııııııııııııııııııııııııııııııııııııııııııı") 
                            console.log(isim);           
                            var servResp = {};
                            servResp.success = true;
                            servResp.redirect = true;
                            servResp.redirectURL = "http://localhost:1000/SearchEngine?name=" +isim;
                            res.send(servResp);  
                        });
 
app.listen(1000);